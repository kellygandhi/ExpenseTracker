# FinTrack — Expense Analytics System

Django + SQLite + Chart.js expense tracking platform with analytics dashboards, authentication, and budget management.

## Features
- **Authentication** — Register, login, logout with Django's auth system
- **Expense Management** — Add, edit, delete expenses with 10 categories
- **Analytics Dashboard** — Daily spending, category breakdown, monthly trends (Chart.js)
- **Budget Tracking** — Set monthly budgets per category with progress bars
- **Advanced Analytics** — Year-over-year monthly bars, radar chart (day of week), category pie
- **Filtering** — Filter expenses by category, month, year, or search term

## Tech Stack
- **Backend:** Django 4.2, Django ORM
- **Database:** SQLite
- **Frontend:** Vanilla HTML/CSS/JS + Chart.js 4.4
- **Auth:** Django's built-in authentication

## Project Structure
```
fintrack/
├── fintrack/               # Django project config
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── expenses/               # Main app
│   ├── models.py           # Expense, Budget, Category
│   ├── views.py            # All view logic
│   ├── forms.py            # Django forms
│   ├── urls.py             # URL routing
│   ├── admin.py
│   ├── migrations/
│   ├── management/
│   │   └── commands/
│   │       └── seed_demo.py  # Demo data seeder
│   └── templates/
│       └── expenses/
│           ├── dashboard.html
│           ├── expense_list.html
│           ├── expense_form.html
│           ├── expense_confirm_delete.html
│           ├── analytics.html
│           └── budgets.html
├── templates/
│   ├── base.html
│   └── registration/
│       ├── login.html
│       └── register.html
├── static/
│   ├── css/main.css
│   └── js/
│       ├── main.js
│       ├── dashboard.js
│       └── analytics.js
├── requirements.txt
└── manage.py
```

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Apply migrations
```bash
python manage.py migrate
```

### 3. (Optional) Load demo data
```bash
python manage.py seed_demo
# Creates user: demo / demo1234 with 6 months of expense data
```

### 4. Create your own admin user
```bash
python manage.py createsuperuser
```

### 5. Run the development server
```bash
python manage.py runserver
```

Visit **http://127.0.0.1:8000** → redirects to login.

## Pages

| URL | Description |
|-----|-------------|
| `/login/` | Login page |
| `/register/` | Registration |
| `/dashboard/` | Main analytics dashboard |
| `/expenses/` | Expense list with filters |
| `/expenses/add/` | Add new expense |
| `/expenses/<id>/edit/` | Edit expense |
| `/analytics/` | Deep analytics (monthly bars, radar, pie) |
| `/budgets/` | Budget management |
| `/admin/` | Django admin panel |
| `/api/monthly/?year=2025` | JSON API for monthly data |

## Models

### Expense
- `user`, `title`, `amount`, `category`, `date`, `description`

### Budget
- `user`, `category`, `monthly_limit`, `month`, `year`

### Category (choices)
food, transport, housing, utilities, healthcare, entertainment, shopping, education, travel, other
