// FinTrack — analytics.js
document.addEventListener('DOMContentLoaded', () => {

  // ── Monthly bar chart ──────────────────────────────────────
  const monthlyCtx = document.getElementById('monthlyBarChart');
  if (monthlyCtx) {
    new Chart(monthlyCtx, {
      type: 'bar',
      data: {
        labels: MONTHLY_LABELS,
        datasets: [{
          label: 'Monthly Spending (₹)',
          data: MONTHLY_AMOUNTS,
          backgroundColor: MONTHLY_AMOUNTS.map(v =>
            v === Math.max(...MONTHLY_AMOUNTS) ? '#f59e0b' : 'rgba(99,102,241,0.5)'
          ),
          borderColor: MONTHLY_AMOUNTS.map(v =>
            v === Math.max(...MONTHLY_AMOUNTS) ? '#f59e0b' : '#6366f1'
          ),
          borderWidth: 1,
          borderRadius: 6,
          borderSkipped: false,
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: { label: ctx => ` ₹${ctx.parsed.y.toLocaleString('en-IN')}` }
          }
        },
        scales: {
          x: { grid: { display: false } },
          y: {
            grid: { color: '#252945' },
            ticks: { callback: v => '₹' + v.toLocaleString('en-IN'), font: { size: 11 } }
          }
        }
      }
    });
  }

  // ── Day of week polar chart ────────────────────────────────
  const dowCtx = document.getElementById('dowChart');
  if (dowCtx) {
    new Chart(dowCtx, {
      type: 'radar',
      data: {
        labels: DOW_LABELS,
        datasets: [{
          label: 'Spending (₹)',
          data: DOW_AMOUNTS,
          backgroundColor: 'rgba(99,102,241,0.15)',
          borderColor: '#6366f1',
          borderWidth: 2,
          pointBackgroundColor: '#6366f1',
          pointBorderColor: '#0d0f1a',
          pointBorderWidth: 2,
          pointRadius: 5,
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: { label: ctx => ` ₹${ctx.parsed.r.toLocaleString('en-IN')}` }
          }
        },
        scales: {
          r: {
            grid: { color: '#252945' },
            angleLines: { color: '#252945' },
            ticks: { backdropColor: 'transparent', font: { size: 10 } }
          }
        }
      }
    });
  }

  // ── Category pie chart ─────────────────────────────────────
  const catCtx = document.getElementById('catPieChart');
  if (catCtx && CAT_NAMES.length > 0) {
    new Chart(catCtx, {
      type: 'pie',
      data: {
        labels: CAT_NAMES,
        datasets: [{
          data: CAT_TOTALS,
          backgroundColor: CAT_COLORS,
          borderColor: '#131625',
          borderWidth: 3,
          hoverOffset: 6,
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'bottom', labels: { font: { size: 11 }, padding: 10 } },
          tooltip: {
            callbacks: { label: ctx => ` ₹${ctx.parsed.toLocaleString('en-IN')}` }
          }
        }
      }
    });
  }

  // ── Category table ─────────────────────────────────────────
  const tbody = document.getElementById('catTableBody');
  if (tbody && CAT_NAMES.length > 0) {
    CAT_NAMES.forEach((name, i) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>
          <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${CAT_COLORS[i]};margin-right:8px;"></span>
          ${name}
        </td>
        <td style="color:#8b90b8">${CAT_COUNTS[i]}</td>
        <td style="font-family:'Space Grotesk',sans-serif;font-weight:600;color:#e8eaf6">₹${CAT_TOTALS[i].toLocaleString('en-IN', {minimumFractionDigits:2})}</td>
      `;
      tbody.appendChild(row);
    });
  } else if (tbody) {
    tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#5a5f80;padding:2rem">No data available.</td></tr>';
  }

});
