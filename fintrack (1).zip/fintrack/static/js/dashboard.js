// FinTrack — dashboard.js
document.addEventListener('DOMContentLoaded', () => {

  // ── Daily spending line chart ──────────────────────────────
  const dailyCtx = document.getElementById('dailyChart');
  if (dailyCtx) {
    new Chart(dailyCtx, {
      type: 'line',
      data: {
        labels: DAILY_LABELS,
        datasets: [{
          label: 'Daily Spending (₹)',
          data: DAILY_AMOUNTS,
          borderColor: '#6366f1',
          backgroundColor: 'rgba(99,102,241,0.08)',
          borderWidth: 2,
          fill: true,
          tension: 0.4,
          pointRadius: 3,
          pointBackgroundColor: '#6366f1',
          pointBorderColor: '#0d0f1a',
          pointBorderWidth: 2,
          pointHoverRadius: 6,
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => ` ₹${ctx.parsed.y.toLocaleString('en-IN')}`
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { maxTicksLimit: 8, font: { size: 11 } }
          },
          y: {
            grid: { color: '#252945' },
            ticks: {
              font: { size: 11 },
              callback: v => '₹' + v.toLocaleString('en-IN')
            }
          }
        }
      }
    });
  }

  // ── Category donut chart ───────────────────────────────────
  const catCtx = document.getElementById('categoryChart');
  if (catCtx && CAT_LABELS.length > 0) {
    new Chart(catCtx, {
      type: 'doughnut',
      data: {
        labels: CAT_LABELS,
        datasets: [{
          data: CAT_AMOUNTS,
          backgroundColor: CAT_COLORS,
          borderColor: '#131625',
          borderWidth: 3,
          hoverOffset: 6,
        }]
      },
      options: {
        responsive: true,
        cutout: '68%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: { font: { size: 11 }, padding: 12 }
          },
          tooltip: {
            callbacks: {
              label: ctx => ` ₹${ctx.parsed.toLocaleString('en-IN')}`
            }
          }
        }
      }
    });
  } else if (catCtx) {
    catCtx.parentElement.innerHTML = '<p style="color:#5a5f80;text-align:center;padding:2rem;font-size:.875rem;">No expenses this month.</p>';
  }

  // ── Monthly trend bar chart ────────────────────────────────
  const monthlyCtx = document.getElementById('monthlyChart');
  if (monthlyCtx) {
    new Chart(monthlyCtx, {
      type: 'bar',
      data: {
        labels: MONTHLY_LABELS,
        datasets: [{
          label: 'Monthly Total (₹)',
          data: MONTHLY_TREND,
          backgroundColor: MONTHLY_TREND.map((_, i, arr) =>
            i === arr.length - 1 ? '#6366f1' : 'rgba(99,102,241,0.35)'
          ),
          borderColor: MONTHLY_TREND.map((_, i, arr) =>
            i === arr.length - 1 ? '#818cf8' : '#6366f1'
          ),
          borderWidth: 1,
          borderRadius: 6,
          borderSkipped: false,
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => ` ₹${ctx.parsed.y.toLocaleString('en-IN')}`
            }
          }
        },
        scales: {
          x: { grid: { display: false } },
          y: {
            grid: { color: '#252945' },
            ticks: {
              font: { size: 11 },
              callback: v => '₹' + v.toLocaleString('en-IN')
            }
          }
        }
      }
    });
  }

});
