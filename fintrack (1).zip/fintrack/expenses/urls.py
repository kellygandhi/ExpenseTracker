from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('expenses/', views.expense_list, name='expense_list'),
    path('expenses/add/', views.add_expense, name='add_expense'),
    path('expenses/<int:pk>/edit/', views.edit_expense, name='edit_expense'),
    path('expenses/<int:pk>/delete/', views.delete_expense, name='delete_expense'),
    path('analytics/', views.analytics, name='analytics'),
    path('budgets/', views.budgets, name='budgets'),
    path('budgets/<int:pk>/delete/', views.delete_budget, name='delete_budget'),
    path('api/monthly/', views.api_monthly_data, name='api_monthly_data'),
]
