"""
Management command to seed the database with demo data.
Run: python manage.py seed_demo
"""
import random
from datetime import date, timedelta
from decimal import Decimal
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from expenses.models import Expense, Budget


DEMO_EXPENSES = {
    'food': [
        ('Lunch at Swiggy', 250), ('Grocery - BigBasket', 1200), ('Coffee - Starbucks', 380),
        ('Dinner - Zomato', 450), ('Chai & Snacks', 80), ('Weekend BBQ groceries', 900),
    ],
    'transport': [
        ('Uber - Office commute', 180), ('Petrol refill', 2500), ('Ola cab', 220),
        ('Metro pass recharge', 500), ('Auto rickshaw', 60),
    ],
    'housing': [
        ('Monthly Rent', 18000), ('Maintenance charges', 800), ('Electricity bill', 1100),
    ],
    'utilities': [
        ('Internet - Jio Fiber', 799), ('Mobile recharge', 399), ('OTT subscriptions', 649),
        ('Water bill', 200),
    ],
    'entertainment': [
        ('Movie tickets - PVR', 680), ('Gaming top-up', 500), ('Concert tickets', 1200),
    ],
    'shopping': [
        ('Amazon - Electronics', 3500), ('Clothes - Myntra', 1800), ('Books - Amazon', 650),
        ('Shoes', 2200),
    ],
    'healthcare': [
        ('Doctor consultation', 500), ('Pharmacy', 320), ('Gym membership', 1500),
    ],
    'education': [
        ('Udemy course', 449), ('Python book', 399), ('Online workshop', 999),
    ],
}


class Command(BaseCommand):
    help = 'Seed demo user and expense data'

    def handle(self, *args, **kwargs):
        # Create demo user
        user, created = User.objects.get_or_create(
            username='demo',
            defaults={
                'email': 'demo@fintrack.app',
                'first_name': 'Demo',
            }
        )
        if created:
            user.set_password('demo1234')
            user.save()
            self.stdout.write('Created demo user: demo / demo1234')
        else:
            self.stdout.write('Demo user already exists')

        # Create expenses for last 6 months
        today = date.today()
        created_count = 0

        for months_back in range(6):
            month_start = date(today.year, today.month, 1) - timedelta(days=months_back * 30)

            for category, expense_list in DEMO_EXPENSES.items():
                count = random.randint(2, 4)
                samples = random.choices(expense_list, k=count)
                for title, base_amount in samples:
                    amount = Decimal(str(base_amount * random.uniform(0.8, 1.3))).quantize(Decimal('0.01'))
                    day_offset = random.randint(0, 28)
                    expense_date = month_start + timedelta(days=day_offset)
                    if expense_date > today:
                        expense_date = today

                    Expense.objects.create(
                        user=user,
                        title=title,
                        amount=amount,
                        category=category,
                        date=expense_date,
                    )
                    created_count += 1

        # Set budgets for current month
        budgets = {
            'food': 5000, 'transport': 3000, 'entertainment': 2000,
            'shopping': 4000, 'utilities': 2000, 'healthcare': 2000,
        }
        for cat, limit in budgets.items():
            Budget.objects.get_or_create(
                user=user, category=cat, month=today.month, year=today.year,
                defaults={'monthly_limit': limit}
            )

        self.stdout.write(self.style.SUCCESS(
            f'✓ Created {created_count} demo expenses and {len(budgets)} budgets'
        ))
        self.stdout.write('Login at /login/ with: demo / demo1234')
