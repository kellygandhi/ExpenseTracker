from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('auth', '0012_alter_user_first_name_max_length'),
    ]

    operations = [
        migrations.CreateModel(
            name='Category',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(choices=[('food', 'Food & Dining'), ('transport', 'Transport'), ('housing', 'Housing & Rent'), ('utilities', 'Utilities'), ('healthcare', 'Healthcare'), ('entertainment', 'Entertainment'), ('shopping', 'Shopping'), ('education', 'Education'), ('travel', 'Travel'), ('other', 'Other')], max_length=50, unique=True)),
                ('user', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name='categories', to='auth.user')),
            ],
            options={'verbose_name_plural': 'categories'},
        ),
        migrations.CreateModel(
            name='Expense',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=200)),
                ('amount', models.DecimalField(decimal_places=2, max_digits=10)),
                ('category', models.CharField(choices=[('food', 'Food & Dining'), ('transport', 'Transport'), ('housing', 'Housing & Rent'), ('utilities', 'Utilities'), ('healthcare', 'Healthcare'), ('entertainment', 'Entertainment'), ('shopping', 'Shopping'), ('education', 'Education'), ('travel', 'Travel'), ('other', 'Other')], default='other', max_length=50)),
                ('date', models.DateField(default=django.utils.timezone.now)),
                ('description', models.TextField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='expenses', to='auth.user')),
            ],
            options={'ordering': ['-date', '-created_at']},
        ),
        migrations.CreateModel(
            name='Budget',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('category', models.CharField(choices=[('food', 'Food & Dining'), ('transport', 'Transport'), ('housing', 'Housing & Rent'), ('utilities', 'Utilities'), ('healthcare', 'Healthcare'), ('entertainment', 'Entertainment'), ('shopping', 'Shopping'), ('education', 'Education'), ('travel', 'Travel'), ('other', 'Other')], max_length=50)),
                ('monthly_limit', models.DecimalField(decimal_places=2, max_digits=10)),
                ('month', models.IntegerField()),
                ('year', models.IntegerField()),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='budgets', to='auth.user')),
            ],
            options={'unique_together': {('user', 'category', 'month', 'year')}},
        ),
    ]
