from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib import messages
from django.db.models import Sum, Count, Avg
from django.db.models.functions import TruncMonth, TruncDay
from django.utils import timezone
from django.http import JsonResponse
from datetime import datetime, timedelta
from decimal import Decimal
import json

from .models import Expense, Budget, Category
from .forms import ExpenseForm, BudgetForm, FilterForm, RegisterForm


def register(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Welcome to FinTrack, {user.first_name or user.username}!')
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})


@login_required
def dashboard(request):
    today = timezone.now().date()
    current_month = today.month
    current_year = today.year

    # Current month stats
    month_expenses = Expense.objects.filter(
        user=request.user,
        date__month=current_month,
        date__year=current_year
    )
    total_month = month_expenses.aggregate(total=Sum('amount'))['total'] or Decimal('0')
    expense_count = month_expenses.count()

    # Previous month comparison
    if current_month == 1:
        prev_month, prev_year = 12, current_year - 1
    else:
        prev_month, prev_year = current_month - 1, current_year

    prev_total = Expense.objects.filter(
        user=request.user,
        date__month=prev_month,
        date__year=prev_year
    ).aggregate(total=Sum('amount'))['total'] or Decimal('0')

    change_pct = 0
    if prev_total > 0:
        change_pct = ((total_month - prev_total) / prev_total) * 100

    # Category breakdown for pie chart
    cat_data = month_expenses.values('category').annotate(total=Sum('amount')).order_by('-total')
    category_labels = []
    category_amounts = []
    category_colors = []
    for item in cat_data:
        category_labels.append(dict(Category.CATEGORY_CHOICES).get(item['category'], item['category']))
        category_amounts.append(float(item['total']))
        category_colors.append(Category.COLOR_MAP.get(item['category'], '#AEB6BF'))

    # Daily spending for last 30 days
    thirty_days_ago = today - timedelta(days=29)
    daily_data = Expense.objects.filter(
        user=request.user,
        date__gte=thirty_days_ago
    ).values('date').annotate(total=Sum('amount')).order_by('date')

    daily_labels = []
    daily_amounts = []
    date_map = {item['date'].strftime('%Y-%m-%d'): float(item['total']) for item in daily_data}
    for i in range(30):
        d = thirty_days_ago + timedelta(days=i)
        daily_labels.append(d.strftime('%b %d'))
        daily_amounts.append(date_map.get(d.strftime('%Y-%m-%d'), 0))

    # Monthly trend (last 6 months)
    monthly_trend = []
    monthly_labels = []
    for i in range(5, -1, -1):
        if current_month - i <= 0:
            m = current_month - i + 12
            y = current_year - 1
        else:
            m = current_month - i
            y = current_year
        total = Expense.objects.filter(
            user=request.user, date__month=m, date__year=y
        ).aggregate(t=Sum('amount'))['t'] or 0
        monthly_trend.append(float(total))
        monthly_labels.append(datetime(y, m, 1).strftime('%b %Y'))

    # Budget tracking
    budgets = Budget.objects.filter(user=request.user, month=current_month, year=current_year)
    budget_status = []
    for b in budgets:
        spent = month_expenses.filter(category=b.category).aggregate(t=Sum('amount'))['t'] or Decimal('0')
        pct = min(int((spent / b.monthly_limit) * 100), 100) if b.monthly_limit > 0 else 0
        budget_status.append({
            'category': b.get_category_display(),
            'category_key': b.category,
            'limit': b.monthly_limit,
            'spent': spent,
            'remaining': max(b.monthly_limit - spent, Decimal('0')),
            'percentage': pct,
            'over': spent > b.monthly_limit,
            'icon': Category.ICON_MAP.get(b.category, '📦'),
            'color': Category.COLOR_MAP.get(b.category, '#AEB6BF'),
        })

    # Recent expenses
    recent_expenses = Expense.objects.filter(user=request.user).select_related()[:8]

    # Top category this month
    top_cat = cat_data.first()
    top_category = dict(Category.CATEGORY_CHOICES).get(top_cat['category'], 'N/A') if top_cat else 'None'

    context = {
        'total_month': total_month,
        'expense_count': expense_count,
        'change_pct': round(change_pct, 1),
        'change_positive': change_pct > 0,
        'top_category': top_category,
        'avg_daily': round(total_month / 30, 2),
        'recent_expenses': recent_expenses,
        'budget_status': budget_status,
        'category_labels': json.dumps(category_labels),
        'category_amounts': json.dumps(category_amounts),
        'category_colors': json.dumps(category_colors),
        'daily_labels': json.dumps(daily_labels),
        'daily_amounts': json.dumps(daily_amounts),
        'monthly_labels': json.dumps(monthly_labels),
        'monthly_trend': json.dumps(monthly_trend),
        'current_month_name': today.strftime('%B %Y'),
    }
    return render(request, 'expenses/dashboard.html', context)


@login_required
def expense_list(request):
    form = FilterForm(request.GET)
    expenses = Expense.objects.filter(user=request.user)

    if form.is_valid():
        if form.cleaned_data.get('category'):
            expenses = expenses.filter(category=form.cleaned_data['category'])
        if form.cleaned_data.get('month'):
            expenses = expenses.filter(date__month=form.cleaned_data['month'])
        if form.cleaned_data.get('year'):
            expenses = expenses.filter(date__year=form.cleaned_data['year'])
        if form.cleaned_data.get('search'):
            expenses = expenses.filter(title__icontains=form.cleaned_data['search'])

    total = expenses.aggregate(total=Sum('amount'))['total'] or 0

    context = {
        'expenses': expenses,
        'form': form,
        'total': total,
        'count': expenses.count(),
    }
    return render(request, 'expenses/expense_list.html', context)


@login_required
def add_expense(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            messages.success(request, f'Expense "{expense.title}" added successfully!')
            return redirect('expense_list')
    else:
        form = ExpenseForm(initial={'date': timezone.now().date()})
    return render(request, 'expenses/expense_form.html', {'form': form, 'title': 'Add Expense'})


@login_required
def edit_expense(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    if request.method == 'POST':
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            messages.success(request, 'Expense updated successfully!')
            return redirect('expense_list')
    else:
        form = ExpenseForm(instance=expense)
    return render(request, 'expenses/expense_form.html', {'form': form, 'title': 'Edit Expense', 'expense': expense})


@login_required
def delete_expense(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    if request.method == 'POST':
        title = expense.title
        expense.delete()
        messages.success(request, f'"{title}" deleted.')
        return redirect('expense_list')
    return render(request, 'expenses/expense_confirm_delete.html', {'expense': expense})


@login_required
def analytics(request):
    today = timezone.now().date()
    current_year = today.year

    # Yearly monthly breakdown
    monthly_data = {}
    for m in range(1, 13):
        total = Expense.objects.filter(
            user=request.user, date__month=m, date__year=current_year
        ).aggregate(t=Sum('amount'))['t'] or 0
        monthly_data[datetime(current_year, m, 1).strftime('%b')] = float(total)

    # Category breakdown all time
    all_cat = Expense.objects.filter(user=request.user).values('category').annotate(
        total=Sum('amount'), count=Count('id')
    ).order_by('-total')

    cat_names, cat_totals, cat_counts, cat_colors = [], [], [], []
    for item in all_cat:
        cat_names.append(dict(Category.CATEGORY_CHOICES).get(item['category'], item['category']))
        cat_totals.append(float(item['total']))
        cat_counts.append(item['count'])
        cat_colors.append(Category.COLOR_MAP.get(item['category'], '#AEB6BF'))

    # Weekly pattern (day of week)
    from django.db.models.functions import ExtractWeekDay
    dow_data = Expense.objects.filter(user=request.user).annotate(
        dow=ExtractWeekDay('date')
    ).values('dow').annotate(total=Sum('amount')).order_by('dow')
    dow_map = {i['dow']: float(i['total']) for i in dow_data}
    days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
    dow_amounts = [dow_map.get(i + 1, 0) for i in range(7)]

    # All-time stats
    all_expenses = Expense.objects.filter(user=request.user)
    total_all = all_expenses.aggregate(t=Sum('amount'))['t'] or 0
    avg_expense = all_expenses.aggregate(a=Avg('amount'))['a'] or 0
    biggest = all_expenses.order_by('-amount').first()

    context = {
        'monthly_labels': json.dumps(list(monthly_data.keys())),
        'monthly_amounts': json.dumps(list(monthly_data.values())),
        'cat_names': json.dumps(cat_names),
        'cat_totals': json.dumps(cat_totals),
        'cat_counts': json.dumps(cat_counts),
        'cat_colors': json.dumps(cat_colors),
        'dow_labels': json.dumps(days),
        'dow_amounts': json.dumps(dow_amounts),
        'total_all': total_all,
        'avg_expense': round(avg_expense, 2),
        'biggest': biggest,
        'current_year': current_year,
    }
    return render(request, 'expenses/analytics.html', context)


@login_required
def budgets(request):
    today = timezone.now().date()
    current_month = today.month
    current_year = today.year

    if request.method == 'POST':
        form = BudgetForm(request.POST)
        if form.is_valid():
            budget, created = Budget.objects.update_or_create(
                user=request.user,
                category=form.cleaned_data['category'],
                month=form.cleaned_data['month'],
                year=form.cleaned_data['year'],
                defaults={'monthly_limit': form.cleaned_data['monthly_limit']}
            )
            messages.success(request, 'Budget saved!' if created else 'Budget updated!')
            return redirect('budgets')
    else:
        form = BudgetForm(initial={'month': current_month, 'year': current_year})

    budget_list = Budget.objects.filter(
        user=request.user, month=current_month, year=current_year
    )
    budget_data = []
    for b in budget_list:
        spent = Expense.objects.filter(
            user=request.user, category=b.category,
            date__month=b.month, date__year=b.year
        ).aggregate(t=Sum('amount'))['t'] or Decimal('0')
        pct = min(int((spent / b.monthly_limit) * 100), 100) if b.monthly_limit > 0 else 0
        budget_data.append({
            'budget': b,
            'spent': spent,
            'remaining': max(b.monthly_limit - spent, Decimal('0')),
            'percentage': pct,
            'over': spent > b.monthly_limit,
            'icon': Category.ICON_MAP.get(b.category, '📦'),
            'color': Category.COLOR_MAP.get(b.category, '#AEB6BF'),
        })

    context = {
        'form': form,
        'budget_data': budget_data,
        'current_month_name': today.strftime('%B %Y'),
    }
    return render(request, 'expenses/budgets.html', context)


@login_required
def delete_budget(request, pk):
    budget = get_object_or_404(Budget, pk=pk, user=request.user)
    if request.method == 'POST':
        budget.delete()
        messages.success(request, 'Budget removed.')
    return redirect('budgets')


@login_required
def api_monthly_data(request):
    """API endpoint for dynamic chart updates"""
    year = int(request.GET.get('year', timezone.now().year))
    data = []
    for m in range(1, 13):
        total = Expense.objects.filter(
            user=request.user, date__month=m, date__year=year
        ).aggregate(t=Sum('amount'))['t'] or 0
        data.append({'month': datetime(year, m, 1).strftime('%b'), 'total': float(total)})
    return JsonResponse({'data': data})
