from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


class Category(models.Model):
    CATEGORY_CHOICES = [
        ('food', 'Food & Dining'),
        ('transport', 'Transport'),
        ('housing', 'Housing & Rent'),
        ('utilities', 'Utilities'),
        ('healthcare', 'Healthcare'),
        ('entertainment', 'Entertainment'),
        ('shopping', 'Shopping'),
        ('education', 'Education'),
        ('travel', 'Travel'),
        ('other', 'Other'),
    ]

    ICON_MAP = {
        'food': '🍽️',
        'transport': '🚗',
        'housing': '🏠',
        'utilities': '💡',
        'healthcare': '🏥',
        'entertainment': '🎬',
        'shopping': '🛍️',
        'education': '📚',
        'travel': '✈️',
        'other': '📦',
    }

    COLOR_MAP = {
        'food': '#FF6B6B',
        'transport': '#4ECDC4',
        'housing': '#45B7D1',
        'utilities': '#96CEB4',
        'healthcare': '#FFEAA7',
        'entertainment': '#DDA0DD',
        'shopping': '#98D8C8',
        'education': '#F7DC6F',
        'travel': '#85C1E9',
        'other': '#AEB6BF',
    }

    name = models.CharField(max_length=50, choices=CATEGORY_CHOICES, unique=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='categories', null=True, blank=True)

    class Meta:
        verbose_name_plural = 'categories'

    def __str__(self):
        return self.get_name_display()

    @property
    def icon(self):
        return self.ICON_MAP.get(self.name, '📦')

    @property
    def color(self):
        return self.COLOR_MAP.get(self.name, '#AEB6BF')


class Expense(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='expenses')
    title = models.CharField(max_length=200)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    category = models.CharField(
        max_length=50,
        choices=Category.CATEGORY_CHOICES,
        default='other'
    )
    date = models.DateField(default=timezone.now)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f"{self.title} - ₹{self.amount}"

    @property
    def category_icon(self):
        return Category.ICON_MAP.get(self.category, '📦')

    @property
    def category_color(self):
        return Category.COLOR_MAP.get(self.category, '#AEB6BF')

    @property
    def category_display(self):
        return dict(Category.CATEGORY_CHOICES).get(self.category, 'Other')


class Budget(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='budgets')
    category = models.CharField(
        max_length=50,
        choices=Category.CATEGORY_CHOICES,
    )
    monthly_limit = models.DecimalField(max_digits=10, decimal_places=2)
    month = models.IntegerField()
    year = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['user', 'category', 'month', 'year']

    def __str__(self):
        return f"{self.user.username} - {self.category} - {self.month}/{self.year}"
